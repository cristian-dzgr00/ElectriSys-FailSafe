# Procesos actuales (AS-IS) de Electritorres en BPMN

Seis procesos, cada uno en `.bpmn` (BPMN 2.0, se abre en bpmn.io o Camunda Modeler), `.svg` y `.png`:

1. 01_venta_mostrador
2. 02_cotizacion
3. 03_compra_proveedor
4. 04_recepcion_mercancia
5. 05_control_inventario
6. 06_cierre_caja

Convenciones: círculo verde = inicio, rojo = fin, rombo = decisión, rectángulo = tarea (manual o en Excel), nota roja punteada = problema detectado.

## Supuestos por confirmar con el dueño (tarea 0.12)
Los diagramas parten de lo que ya se sabe de Electritorres (trabajo con Excel, búsqueda por código o de memoria, sin sustitutos sugeridos, stock desactualizado entre cajas) y no de observación directa. Hay que validar:
- Cómo se cobra y qué comprobante se entrega (factura, recibo, ninguno).
- Si las cotizaciones se envían por WhatsApp o impresas.
- Quién decide y hace los pedidos a proveedores y con qué frecuencia.
- Cada cuánto se hace el conteo físico del inventario.
- Si hay cierre de caja diario y quién lo recibe.
