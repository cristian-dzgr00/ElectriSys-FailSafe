#!/bin/sh
# Uso (desde la raíz del repo, con tu rama activa):
#   unzip -o /ruta/sprint3_repo.zip -d /tmp/s3pk && sh /tmp/s3pk/aplicar.sh
set -e
D="$(cd "$(dirname "$0")" && pwd)"
[ -d oracle ] || { echo "Ejecuta esto en la raíz del repo (no existe ./oracle)"; exit 1; }
cp -r "$D/oracle/." oracle/
git add oracle
git commit -m "Sprint 3: normalización 3FN fase 1, vw_totales_documento, scripts re-ejecutables, pruebas de triggers/planes, cargador completo y documentación de la BD"
git push
