"""La tabla de posibles errores en Oracle (vía backend): lectura, diferencias y respaldo en CSV."""
import pytest

from app.ner import agente_errores, almacen_bd, extractor


class OracleFalso:
    """Imita las dos rutas del backend con una tabla en memoria."""

    def __init__(self, filas=None, avisos=None, cae=False):
        self.filas = list(filas or [])
        self.avisos = list(avisos or [])
        self.cae = cae
        self.envios = []

    def cargar(self):
        return None if self.cae else (list(self.filas), list(self.avisos))

    def enviar_cambios(self, upsert, eliminar, avisos):
        if self.cae:
            return False
        self.envios.append((upsert, eliminar, avisos))
        quitar = {(e["tipo"], e["error"]) for e in eliminar}
        self.filas = [f for f in self.filas if (f["tipo"], f["error"]) not in quitar] + list(upsert)
        if avisos is not None:
            self.avisos = list(avisos)
        return True


@pytest.fixture
def oracle(tmp_path, monkeypatch):
    monkeypatch.setenv("NLP_ERRORES_EN_BD", "1")
    monkeypatch.setattr(agente_errores, "RUTA_TABLA", tmp_path / "posibles_errores.csv")
    monkeypatch.setattr(agente_errores, "RUTA_AVISOS", tmp_path / "posibles_errores_avisos.csv")
    monkeypatch.setattr(extractor, "_tabla_en_memoria", extractor._tabla_en_memoria)
    falso = OracleFalso()
    monkeypatch.setattr(almacen_bd, "cargar", lambda: falso.cargar())
    monkeypatch.setattr(almacen_bd, "enviar_cambios", lambda u, e, a: falso.enviar_cambios(u, e, a))
    agente_errores._reiniciar_estado()
    yield falso
    agente_errores._reiniciar_estado()
    extractor._indices_fuzzy.clear()


def test_apagado_por_defecto(monkeypatch):
    monkeypatch.delenv("NLP_ERRORES_EN_BD", raising=False)
    assert not almacen_bd.habilitado()


def test_registrar_nombre_envia_las_filas_nuevas_a_oracle(oracle):
    r = agente_errores.registrar_nombre("marca", "Geely")
    assert r["agregadas"] > 0
    assert oracle.filas, "Oracle debe recibir los errores de la marca nueva"
    assert all(f["correcto"] == "Geely" and f["tipo"] == "marca" for f in oracle.filas)
    assert {"tipo", "error", "correcto", "nivel", "origen", "nota"} <= set(oracle.filas[0])


def test_el_agente_arranca_con_lo_que_hay_en_oracle(oracle):
    oracle.filas = [{"tipo": "modelo", "error": "jilus", "correcto": "Hilux", "nivel": 3, "origen": "auto", "nota": ""}]
    estado = agente_errores._cargar_estado()
    assert estado["filas"]["jilus"]["correcto"] == "Hilux"
    assert extractor.obtener_tabla_errores()["modelo"]["jilus"] == "Hilux"
    assert oracle.envios == []  # nada nuevo que enviar


def test_tabla_vacia_en_oracle_se_siembra_desde_el_csv(oracle, tmp_path):
    (tmp_path / "posibles_errores.csv").write_text(
        "tipo,error,correcto,nivel,origen,nota\nmarca,toyta,Toyota,1,auto,letra faltante\n", encoding="utf-8")
    agente_errores._cargar_estado()
    assert [f["error"] for f in oracle.filas] == ["toyta"]


def test_si_oracle_cae_se_usa_el_csv_y_se_reenvia_despues(oracle, tmp_path):
    (tmp_path / "posibles_errores.csv").write_text(
        "tipo,error,correcto,nivel,origen,nota\nmarca,toyta,Toyota,1,auto,letra faltante\n", encoding="utf-8")
    oracle.cae = True
    agente_errores._cargar_estado()
    agente_errores.registrar_nombre("marca", "Geely")  # no debe lanzar
    assert oracle.filas == []
    assert (tmp_path / "posibles_errores.csv").read_text(encoding="utf-8").count("Geely") > 0
    oracle.cae = False
    agente_errores.registrar_nombre("marca", "Mazda")
    correctos = {f["correcto"] for f in oracle.filas}
    assert {"Geely", "Mazda", "Toyota"} <= correctos  # lo pendiente también llegó


def test_un_error_que_deja_de_ser_valido_se_elimina_en_oracle(oracle):
    agente_errores.registrar_nombre("modelo", "Hilux")
    assert any(f["error"] == "hilus" for f in oracle.filas)
    agente_errores.registrar_nombre("modelo", "Hilus")  # "hilus" pasa a ser un nombre oficial
    assert not any(f["error"] == "hilus" and f["correcto"] == "Hilux" for f in oracle.filas)
