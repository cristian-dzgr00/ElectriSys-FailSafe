"""Almacén de la tabla de posibles errores en Oracle (vía el backend PHP).

El microservicio no se conecta a Oracle: igual que el resto del proyecto,
solo el backend toca la base. Este módulo habla con dos rutas del backend
(backend/src/routes/nlp_errores.php):

    GET  /api/nlp/posibles-errores           -> filas y avisos guardados
    POST /api/nlp/posibles-errores/cambios   -> upsert / eliminar / avisos

Se activa con NLP_ERRORES_EN_BD=1. Apagado (por defecto, y en las pruebas)
el agente usa solo el CSV, como antes. Si el backend no responde, el agente
sigue con el CSV local y reintenta enviar los cambios en el próximo guardado.
"""
import logging
import os

import httpx

from app.config import BACKEND_URL, backend_auth_headers

logger = logging.getLogger(__name__)

RUTA = "/api/nlp/posibles-errores"
TIMEOUT_LECTURA = 30.0   # la tabla completa son ~58 mil filas
TIMEOUT_ESCRITURA = 20.0
LOTE = 1000              # el backend acepta hasta 2000 filas por solicitud


def habilitado() -> bool:
    return os.getenv("NLP_ERRORES_EN_BD", "").strip().lower() in ("1", "true", "si", "sí", "yes")


def cargar() -> tuple[list[dict], list[dict]] | None:
    """(filas, avisos) guardados en Oracle, o None si no se pudo consultar."""
    try:
        with httpx.Client(timeout=TIMEOUT_LECTURA) as client:
            resp = client.get(f"{BACKEND_URL}{RUTA}", headers=backend_auth_headers())
            resp.raise_for_status()
            cuerpo = resp.json()
        return cuerpo.get("data", []), cuerpo.get("avisos", [])
    except Exception as e:
        logger.warning("No se pudo leer la tabla de errores desde Oracle: %s", e)
        return None


def _post(cuerpo: dict) -> None:
    with httpx.Client(timeout=TIMEOUT_ESCRITURA) as client:
        resp = client.post(f"{BACKEND_URL}{RUTA}/cambios", json=cuerpo, headers=backend_auth_headers())
        resp.raise_for_status()


def enviar_cambios(upsert: list[dict], eliminar: list[dict], avisos: list[dict] | None) -> bool:
    """Envía los cambios en lotes. True si Oracle los aplicó todos.

    Las eliminaciones y los avisos van en el primer lote; cada lote es una
    transacción. Si algún lote falla, devuelve False y el agente vuelve a
    calcular la diferencia en el próximo guardado.
    """
    try:
        lotes = [upsert[i:i + LOTE] for i in range(0, len(upsert), LOTE)] or [[]]
        for n, lote in enumerate(lotes):
            _post({
                "upsert": lote,
                "eliminar": eliminar if n == 0 else [],
                "avisos": avisos if n == 0 else None,
            })
        return True
    except Exception as e:
        logger.warning("No se pudieron guardar los cambios de errores en Oracle: %s", e)
        return False
