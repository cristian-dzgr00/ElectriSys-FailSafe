<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\models\Database;

/**
 * Tabla de posibles errores del asistente NLP (Oracle: posibles_errores y
 * posibles_errores_avisos, ver oracle/13_posibles_errores.sql).
 *
 * Solo la usa el microservicio nlp-service, con su JWT de servicio: el
 * microservicio no se conecta a Oracle, igual que el resto del proyecto
 * (el backend es el único que toca la base).
 */
const NLP_ERRORES_TIPOS = ['marca', 'modelo', 'categoria'];

function nlpErroresJson(Response $res, array $payload, int $status = 200): Response
{
    $res->getBody()->write(json_encode($payload, JSON_UNESCAPED_UNICODE));
    return $res->withStatus($status)->withHeader('Content-Type', 'application/json');
}

// GET /api/nlp/posibles-errores
$group->get('/nlp/posibles-errores', function (Request $req, Response $res) {
    $db = Database::getConnection();
    $filas = $db->query(
        "SELECT tipo, error, correcto, nivel, origen, nota FROM posibles_errores"
    )->fetchAll();
    $avisos = $db->query(
        "SELECT tipo, error, correcto, nivel, motivo FROM posibles_errores_avisos"
    )->fetchAll();
    return nlpErroresJson($res, ['data' => $filas, 'avisos' => $avisos]);
});

// POST /api/nlp/posibles-errores/cambios
// Cuerpo: {"upsert":[{tipo,error,correcto,nivel,origen,nota}],
//          "eliminar":[{tipo,error}],
//          "avisos":[{tipo,error,correcto,nivel,motivo}] | null}
// "avisos": null no toca la tabla de avisos; una lista la reemplaza completa.
// Todo en una sola transacción: o se aplica el cambio completo o nada.
$group->post('/nlp/posibles-errores/cambios', function (Request $req, Response $res) {
    $b        = (array) $req->getParsedBody();
    $upsert   = is_array($b['upsert']   ?? null) ? $b['upsert']   : [];
    $eliminar = is_array($b['eliminar'] ?? null) ? $b['eliminar'] : [];
    $avisos   = is_array($b['avisos']   ?? null) ? $b['avisos']   : null;

    if (count($upsert) > 2000 || count($eliminar) > 2000) {
        return nlpErroresJson($res, ['error' => 'Máximo 2000 filas por solicitud'], 413);
    }
    foreach (array_merge($upsert, $eliminar, $avisos ?? []) as $f) {
        if (!in_array($f['tipo'] ?? '', NLP_ERRORES_TIPOS, true)) {
            return nlpErroresJson($res, ['error' => 'Tipo inválido'], 400);
        }
    }

    $db = Database::getConnection();
    try {
        $db->beginTransaction();

        $del = $db->prepare("DELETE FROM posibles_errores WHERE tipo = ? AND error = ?");
        foreach ($eliminar as $f) {
            $del->execute([$f['tipo'], mb_substr((string) $f['error'], 0, 100)]);
        }

        $merge = $db->prepare("
            MERGE INTO posibles_errores t
            USING (SELECT ? AS tipo, ? AS error, ? AS correcto FROM dual) s
               ON (t.tipo = s.tipo AND t.error = s.error AND t.correcto = s.correcto)
             WHEN MATCHED THEN UPDATE SET t.nivel = ?, t.origen = ?, t.nota = ?
             WHEN NOT MATCHED THEN INSERT (tipo, error, correcto, nivel, origen, nota)
                  VALUES (s.tipo, s.error, s.correcto, ?, ?, ?)
        ");
        foreach ($upsert as $f) {
            $nivel  = max(1, min(4, (int) ($f['nivel'] ?? 1)));
            $origen = ($f['origen'] ?? 'auto') === 'manual' ? 'manual' : 'auto';
            $nota   = mb_substr((string) ($f['nota'] ?? ''), 0, 100);
            $merge->execute([
                $f['tipo'], mb_substr((string) $f['error'], 0, 100), mb_substr((string) $f['correcto'], 0, 100),
                $nivel, $origen, $nota,
                $nivel, $origen, $nota,
            ]);
        }

        if ($avisos !== null) {
            $db->query("DELETE FROM posibles_errores_avisos");
            $ins = $db->prepare("
                INSERT INTO posibles_errores_avisos (tipo, error, correcto, nivel, motivo)
                VALUES (?, ?, ?, ?, ?)
            ");
            foreach ($avisos as $a) {
                $ins->execute([
                    $a['tipo'], mb_substr((string) $a['error'], 0, 100), mb_substr((string) $a['correcto'], 0, 100),
                    max(1, min(4, (int) ($a['nivel'] ?? 1))), mb_substr((string) ($a['motivo'] ?? ''), 0, 100),
                ]);
            }
        }

        $db->commit();
        return nlpErroresJson($res, ['success' => true, 'upsert' => count($upsert), 'eliminar' => count($eliminar)]);
    } catch (\Throwable $e) {
        $db->rollBack();
        error_log('[ElectriSys] No se pudieron guardar los posibles errores: ' . $e->getMessage());
        return nlpErroresJson($res, ['error' => 'No se pudieron guardar los cambios'], 500);
    }
});
